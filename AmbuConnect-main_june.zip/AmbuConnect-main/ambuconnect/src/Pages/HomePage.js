import React, { memo } from "react";
import Landing from "../Components/Landing";

const HomePage = () => {
  return (
    <div>
      <Landing />
    </div>
  );
};

export default memo(HomePage);
